#!/bin/bash 
while (( "$#" )); do 
  echo $1 
  shift 
done